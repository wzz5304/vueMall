# vueMall
基于vue2.0的商城开发demo，适合练手！
# 安装配置
进入项目：cd vueMall
安装依赖：npm install
运行项目：npm run dev
#技术路线
vue2.0+vuex+axios+vue-router+express+node+mysql
