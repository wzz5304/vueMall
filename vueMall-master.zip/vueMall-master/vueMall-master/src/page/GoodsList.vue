<template>
    <div>
      <div class="index-wrapper">
        <mall-header></mall-header>
        <mall-bread>
        <span>商品列表</span>
        </mall-bread>
        <div class="accessory-result-page accessory-page">
          <div class="container" ref="accHock">
            <div class="filter-nav">
              <span class="sortby">Sort by:</span>
              <a href="javascript:void(0)" class="default cur">Default</a>
              <a href="javascript:void(0)" class="price">Price <svg class="icon icon-arrow-short"><use xlink:href="#icon-arrow-short"></use></svg></a>
              <a href="javascript:void(0)" class="filterby stopPop" @click="filterByPop">Filter by</a>
            </div>
            <div class="accessory-result">
              <!-- filter -->
              <div class="filter stopPop" id="filter" :class="{'filterby-show':filterBy}">
                <dl class="filter-price">
                  <dt>Price:</dt>
                  <dd><a href="javascript:void(0)" :class="{'cur':clickflag==='all'}" @click.stop="setClickAll">All</a></dd>
                  <dd v-for="(price,index) in priceFilter">
                    <a href="javascript:void(0)" :class="{'cur':clickflag===index?true:false}" @click="setClickFlag(index)">{{price.startPrice}}-{{price.endPrice}}</a>
                  </dd>
                </dl>
              </div>

              <!-- search result accessories list -->
              <div class="accessory-list-wrap">
                <div class="accessory-list col-4">
                  <ul>
                    <li v-for="item in goodsList">
                      <div class="pic">
                        <a href="#"><img v-lazy="`static/${item.prodcutImg}`" alt=""></a> <!--v-lazy图片懒加载-->
                      </div>
                      <div class="main">
                        <div class="name">{{item.productName}}</div>
                        <div class="price">{{item.prodcutPrice | formatMoney('元')}}</div>
                        <div class="btn-area">
                          <a href="javascript:;" class="btn btn--m">加入购物车</a>
                        </div>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="md-overlay" v-show="overLayFlag" @click="closePop"></div>
        <mall-footer></mall-footer>
      </div>
    </div>
</template>
<script>
import "../assets/css/base.css"
import "../assets/css/login.css"
import "../assets/css/product.css"
import "../assets/css/checkout.css"
import mallHeader from '../components/header.vue'
import mallFooter from '../components/footer.vue'
import mallBread from '../components/navbread.vue'
// import BScroll from 'better-scroll'
import axios from 'axios'
    export default{
      data() {
          return {
            goodsList:[],
            priceFilter:[
            {
              startPrice: 0,
              endPrice: 500
            },
            {
              startPrice: 500,
              endPrice: 1000
            },
            {
              startPrice: 1000,
              endPrice: 2000
            },
            {
              startPrice: 2000,
              endPrice: 5000
            },
            {
              startPrice: 5000,
              endPrice: 10000
            }
            ],
            clickflag: 'all',
            filterBy: false,
            overLayFlag: false

          }
      },
      created() {
         // this.$nextTick(() => {
         //            if (!this.accScroll) {
         //                 this.accScroll = new BScroll(this.$refs.accHock, {
         //                click: true
         //            });
         //        } else {
         //            this.accScroll.refresh();
         //        }
         //        });
      },
      mounted() {
        this.getGoodList();
        // this.$http.get('/api/goods').then((response) => {
        //   response = response.body;
        //     if (response.errno === 0) {
        //        this.goodsList = response.data;
        //        console.log(this.goodsList);
        // }
        // });
      },
      filters:{
        formatMoney: function(value,type) {
          return "¥" + value.toFixed(2) + type;
        }
      },
      methods: {
        getGoodList() {
          axios.get('/api').then((response) => {
            response = response.data;
            this.goodsList = response;
            console.log(response.data);
          }).catch((error) => {
            console.log('error');
        });
        },
        setClickAll() {
          this.clickflag = 'all';
          this.closePop();
        },
        setClickFlag(index) {
          this.clickflag = index;
          this.closePop();
        },
        filterByPop() {
          let clientWidth = document.body.clientWidth;
            if(clientWidth<=767){
              this.overLayFlag = true;
              this.filterBy = true;
            } 
        },
        closePop() {
          this.overLayFlag = false;
          this.filterBy = false;
        }
      },
      components: {
        mallHeader,
        mallFooter,
        mallBread
      }
    }
</script>
<style lang="stylus" rel="stylesheet/stylus">
  .container
    overflow:hidden
</style>
