<template>
  <div>
    <footer class="footer">
        <div class="footer__wrap">
          <div class="footer__secondary">
            <div class="footer__inner">
              <div class="footer__region">
                <span>站点</span>
                <select class="footer__region__select">
                  <option value="zh-CN">中国</option>
                  <option value="US">美国</option>
                  <option value="UK">英国</option>
                </select>
              </div>
              <div class="footer__secondary__nav">
                <span>Copyright © 2017 Mall 版权所有.</span>
                <a href=":;">
                  关于我们
                </a>
                <a href=":;">
                  团队 &amp; 加入
                </a>
                <a href=":;">
                  商业合作
                </a>
              </div>
            </div>
          </div>
        </div>
      </footer>
  </div>
</template>

<script>
export default {
}
</script>
<style>
</style>
