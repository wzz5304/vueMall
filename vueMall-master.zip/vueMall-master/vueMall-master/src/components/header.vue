<template>
  <div>
    <header class="header">
        <symbol id="icon-cart" viewBox="0 0 38 32">
          <title>cart</title>
        </symbol>
        <div class="navbar">
          <div class="navbar-left-container">
            <a href="/">
              <!--<img class="navbar-brand-logo" src="static/logo.png">-->
              </a>
          </div>
          <div class="navbar-right-container" style="display: flex;">
            <div class="navbar-menu-container">
              <!--<a href="/" class="navbar-link">我的账户</a>-->
              <span class="navbar-link"></span>
              <a href="javascript:void(0)" class="navbar-link" v-if="nameShow" @click="loginShow = true">Login</a>
              <span v-else-if="!nameShow">{{myName}}</span>
              <a href="javascript:void(0)" class="navbar-link" v-if="!nameShow" @click="logout">Logout</a>
              <div class="navbar-cart-container">
                <span class="navbar-cart-count"></span>
                <a class="navbar-link navbar-cart-link" style="vertical-align:middle" href="/#/cart">
                  <i class="icon-shopping_cart"></i>
                </a>
              </div>
            </div>
          </div>
        </div>
        <div class="md-modal modal-msg md-modal-transition" v-bind:class="{'md-show':loginShow}">
          <div class="md-modal-inner">
            <div class="md-top">
              <div class="md-title">Login in</div>
              <button class="md-close" @click="close">Close</button>
            </div>
            <div class="md-content">
              <div class="confirm-tips">
                <div class="error-wrap">
                  <span class="error error-show" v-show="errTip">用户名或者密码错误</span>
                  <span class="error error-show" v-show="errTip1">用户名不存在</span>
                  <span class="error error-show" v-show="errTip2">用户名或密码不能为空</span>

                </div>
                <ul>
                  <li class="regi_form_input">
                    <i class="icon IconPeople"></i>
                    <input type="text" tabindex="1" name="loginname" v-model="userName" class="regi_login_input regi_login_input_left" placeholder="User Name" data-type="loginname" @blur="login">
                  </li>
                  <li class="regi_form_input noMargin">
                    <i class="icon IconPwd"></i>
                    <input type="password" tabindex="2"  name="password" v-model="userPwd" class="regi_login_input regi_login_input_left login-input-no input_text" placeholder="Password" @keyup.enter="login" @blur="login">
                  </li>
                </ul>
              </div>
              <div class="login-wrap">
                <a href="javascript:;" class="btn-login" @click="login">登  录</a>
              </div>
            </div>
          </div>
        </div>
        <div class="md-overlay" v-show="loginShow"></div>
      </header>
  </div>
</template>

<script>
import axios from 'axios'
import "../assets/css/icomoon/style.css"
export default {
  data() {
    return {
      loginShow: false,
      errTip: false,
      errTip2: false,
      errTip3: false,
      userName: '',
      userPwd: '',
      myName: '',
      nameShow: true
    }
  },
  mounted() {
    this.checklogin();
  },
  methods: {
    checklogin() {
      axios.get('/api/users/checkLogin').then((res) => {
        res = res.data;
        if(res.status === '1') {
          this.nameShow = false;
          this.myName = res.result;
        } else {
          this.nameShow = true;
        }
      });
    },
    login() {
      if(!this.userName || !this.userPwd) {
        this.errTip2 = true;
        return;
      }else {
        var param = {
          userId: this.userName,
          userPw: this.userPwd
          };
        axios.get('/api/users/login', {
          params:param //将参数传递给后台
        }).then((res) => {
          res = res.data;
          //console.log(res.msg[0].userName);
          if(res.status==='1') {
            this.myName = res.result[0].userName;
            this.nameShow = false;
            this.close();
            // alert(`${res.msg}`);
          } else if(res.status === '404') {
            this.errTip1 = true;
            this.errTip = false;
            this.errTip2 = false;
          } else if(res.status === '-2') {
            this.errTip = true;
            this.errTip1 = false;
            this.errTip2 = false;
          }
        }).catch((err) => {
          console.log(err);
        });
      }
    },
    logout() { // 注销
      axios.get('/api/users/logout').then((res) => {
        res = res.data;
        if(res.status === '1') {
          this.myName = '';
          this.nameShow = true;
        }
      });
    },
    close() {
      this.loginShow = false;
      this.userName = '';
      this.userPwd = '';
      this.errTip = false;
      this.errTip1 = false;
      this.errTip2 = false;
    }
  }
}
</script>
<style lang="stylus" rel="stylesheet/stylus">
    .header 
      position:fixed
      margin-top: -1px
      z-index:999
</style>
