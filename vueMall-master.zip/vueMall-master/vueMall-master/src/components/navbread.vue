<template>
  <div>
      <div class="nav-breadcrumb-wrap">
        <div class="container">
          <nav class="nav-breadcrumb">
            <router-link to="/">主页</router-link>
            <slot></slot>
          </nav>
        </div>
      </div>
  </div>
</template>
