  create table goods(
  productId int(32) not null primary key auto_increment,
  productName varchar(256) not null,
  prodcutPrice int(32) not null,
  checked varchar(256) not null default '0',
  productNum int(32) not null,
  prodcutImg varchar(256) not null
  )ENGINE=InnoDB DEFAULT CHARSET=utf8

insert into goods(productName,prodcutPrice,prodcutImg) values('小米6','2499','mi6.jpg'),('小米笔记本','3999','note.jpg'),('小米音响','999','1.jpg'),('Leme1','1999','3.jpg'),('乐视盒子','199','5.jpg'),('小米插座','99','6.jpg'),('小米耳机','199','7.jpg'),('小米硬盘400G','1999','8.jpg'),('小米智能电饭煲','399','9.jpg'),('小米TV','5999','10.jpg'),('Leme2','1999','4.jpg'),('数据线','59','15.jpg'),('智能摄像头','999','photo.jpg'),('小米平衡车','1999','pingheng.jpg'),('自拍杆','199','zipai.jpg');
insert into goods(productName,prodcutPrice,prodcutImg) values('小米6','2499','mi6.jpg');