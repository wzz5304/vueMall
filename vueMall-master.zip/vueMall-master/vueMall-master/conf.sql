  create table goods(
  productId int(16) not null primary key auto_increment,
  productName varchar(128) not null,
  prodcutPrice int(32) not null,
  checked varchar(32) not null default '0',
  productNum int(32) not null,
  prodcutImg varchar(256) not null
  )ENGINE=InnoDB DEFAULT CHARSET=utf8

  create table user(
  userId int(16) not null primary key auto_increment,
  userName varchar(64) not null,
  userPwd varchar(64) not null
  )ENGINE=InnoDB DEFAULT CHARSET=utf8

  create table orderList(
  orderId int(16) not null primary key auto_increment,
  userName varchar(64) not null,
  productName varchar(128) not null,
  prodcutPrice int(32) not null,
  productNum int(32) not null,
  prodcutImg varchar(256) not null,
  totalPrice varchar(64) not null,
  checked varchar(32) not null,
  streetName varchar(256) not null,
  postCode varchar(32) not null,
  tel varchar(32) not null
  )ENGINE=InnoDB DEFAULT CHARSET=utf8

  create table cartList(
  cartId int(16) not null primary key auto_increment,
  userName varchar(64) not null,
  productName varchar(128) not null,
  prodcutPrice int(32) not null,
  checked varchar(32) not null,
  productNum int(32) not null,
  prodcutImg varchar(256) not null,
  totalPrice varchar(64) not null
  )ENGINE=InnoDB DEFAULT CHARSET=utf8

  create table addressList(
  addressId int(16) not null primary key auto_increment,
  userName varchar(64) not null,
  streetName varchar(256) not null,
  postCode int(32) not null,
  tel varchar(32) not null,
  isDefault int(4) not null
  )ENGINE=InnoDB DEFAULT CHARSET=utf8

insert into goods(productName,prodcutPrice,prodcutImg) values('小米6','2499','mi6.jpg'),('小米笔记本','3999','note.jpg'),('小米音响','999','1.jpg'),('Leme1','1999','3.jpg'),('乐视盒子','199','5.jpg'),('小米插座','99','6.jpg'),('小米耳机','199','7.jpg'),('小米硬盘400G','1999','8.jpg'),('小米智能电饭煲','399','9.jpg'),('小米TV','5999','10.jpg'),('Leme2','1999','4.jpg'),('数据线','59','15.jpg'),('智能摄像头','999','photo.jpg'),('小米平衡车','1999','pingheng.jpg'),('自拍杆','199','zipai.jpg');
insert into goods(productName,prodcutPrice,prodcutImg) values('小米6','2499','mi6.jpg');