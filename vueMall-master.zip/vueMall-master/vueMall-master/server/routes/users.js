var express = require('express');
var router = express.Router();
var mysql = require('mysql');
// var md5=require('md5');  
var $conf = require('../conf/conf');
// 使用连接池
var pool = mysql.createPool($conf.mysql);
router.use(express.static('public'));
router.get('/', function (req, res, next) {
  if(pool) {
      res.json({
        status:'0000',
        msg:'succees'
      });
    } else {
      res.json({
        status:'-1',
        msg:'error!'
      });
    }
});

router.get('/login', (req, res, next) => {
  var userId = req.param('userId'); // 获取前台传过来的userId值
  //var userPw = trim(md5(req.param('userPwd'))); // 获取前台传过来的密码
  var userPwc = req.param('userPw'); // 获取前台传过来的密码
  if(pool) {
    let sql = `select * from user where userName=${userId}`;
    pool.query(sql, (err, result) => {
      if(err) {
        res.json({
          status:'-1',
          msg:err.message
        });
      } else {
        if(result.length === 0) {
          res.json({
          status:'404',// 用户不存在
          msg:'user not exist'
        });
        } else {
          let checkPw = result[0].userPwd;
          if(userPwc != checkPw) {
            res.json({
              status:'-2',//密码错误
              msg:'password error'
            });
          } else {
            res.json({
              status:'1',
              msg:result
            });
          }
        }
      }
    });
    } else {
      res.json({
        status:'-1',
        msg:'error!'
      });
    }
});

module.exports = router;
