var express = require('express');
var router = express.Router();
var mysql = require('mysql');
// var md5=require('md5');  
var $conf = require('../conf/conf');
// 使用连接池
var pool = mysql.createPool($conf.mysql);
router.use(express.static('public'));
router.get('/', function (req, res, next) {
  if(pool) {
      res.json({
        status:'0000',
        msg:'succees'
      });
    } else {
      res.json({
        status:'-1',
        msg:'error!'
      });
    }
});
// 登录接口
router.get('/login', (req, res, next) => {
  var userId = req.param('userId'); // 获取前台传过来的userId值
  //var userPw = trim(md5(req.param('userPwd'))); // 获取前台传过来的密码
  var userPwc = req.param('userPw'); // 获取前台传过来的密码
  if(pool) {
    let sql = `select * from user where userId=${userId}`;
    pool.query(sql, (err, result) => {
      if(err) {
        res.json({
          status:'-1',
          msg:err.message
        });
      } else {
        if(result.length === 0) {
          res.json({
          status:'404',// 用户不存在
          msg:'user not exist'
        });
        } else {
          let checkPw = result[0].userPwd;
          let myName = result[0].userName;
          let myId = result[0].userId;
          if(userPwc != checkPw) {
            res.json({
              status:'-2',//密码错误
              msg:'password error'
            });
          } else {
            res.cookie('userId', myId, {
              path:'/',
              maxAge:1000*60*60 // 设置cookie时间
            });
            res.cookie('userName', myName, {
              path:'/',
              maxAge:1000*60*60 // 设置cookie时间
            });
            // req.session.user = result; // 设置session
            res.json({
              status:'1',
              msg:'登录成功!',
              result:result
            });
          }
        }
      }
    });
    } else {
      res.json({
        status:'-1',
        msg:'error!'
      });
    }
});
//登出接口
router.get('/logout', function (req,res,next) {
  res.cookie("userId","",{
    path:"/",
    maxAge:-1
  });
  res.cookie("userName","",{
    path:"/",
    maxAge:-1
  });
  res.json({
    status:"1",
    msg:'',
    result:''
  })
});

//检查是否登录
router.get("/checkLogin", function (req,res,next) {
  if(req.cookies.userId){
      res.json({
        status:'1',
        msg:'',
        result:req.cookies.userName || ''
      });
  }else{
    res.json({
      status:'0',
      msg:'未登录',
      result:''
    });
  }
});

// 购物车数据
router.get("/getCartData", (req, res, next) => {
  if(req.cookies && req.cookies.userId) {
    let userId = req.cookies.userId;
    let sql = `select * from cartlist where userId=${userId}`;
    pool.query(sql, (err, result) => {
      if(err) {
        res.json({
          status:'-1',
          msg:err.message
        });
      }else {
        res.json({
          status:'1',
          msg:'获取数据成功',
          result:result
        });
      }
    });

  }else {
    res.json({
      status:'0',
      msg:'未登录'
    });
  }
});

//删除商品信息
router.get("/delProduct", (req, res, next) => {
  if(req.cookies && req.cookies.userId){
    let userId = req.cookies.userId;
    let proId = req.param('productId'); // 获取前台传过来的要删除的productId值
    let sql = `delete from cartlist where productId=${proId} and userId=${userId}`;
    pool.query(sql, (err, result) => {
      if(err) {
        res.json({
          status:'-1',
          msg:err.message
        });
      }else {
        res.json({
          status:'1',
          msg:'删除成功'
        });
      }
    });
  }else {
    res.json({
      status:'0',
      msg:'未登录'
    });
  }
});

// 修改商品数量
router.get("/editProductNum", (req, res, next) => {
  if(req.cookies && req.cookies.userId){
    let userId = req.cookies.userId;
    let proId = req.param('productId'); // 获取前台传过来的要删除的productId值
    let proNum = req.param('productNum'); // 获取前台传过来的要删除的productNum值
    let checked = req.param('checked'); // 获取前台传过来的要删除的chencked值
    let sql = `update cartlist set productNum=${proNum},checked=${checked} where productId=${proId} and userId=${userId}`;
    pool.query(sql, (err, result) => {
      if(err) {
        res.json({
          status:'-1',
          msg:err.message
        });
      } else {
        res.json({
          status:'1',
          msg:'更新成功',
          result:result
        });
      }
    });
  }else {
    res.json({
      status:'0',
      msg:'未登录'
    });
  }
});

//全选购物车商品
router.get("/editSelectAll", (req, res, next) => {
  if(req.cookies && req.cookies.userId){
    let userId = req.cookies.userId;
    let checked = req.param('checked'); // 获取前台传过来的要删除的chencked值
    let sql = `update cartlist set checked=${checked} where userId=${userId}`;
    pool.query(sql, (err, result) => {
      if(err) {
        res.json({
          status:'-1',
          msg:err.message
        });
      } else {
        res.json({
          status:'1',
          msg:'更新成功',
          result:result
        });
      }
    });
  } else {
    res.json({
      status:'0',
      msg:'未登录'
    });
  }
});

//获取用户地址信息
router.get("/addressList", (req, res, next) => {
  if(req.cookies && req.cookies.userId) {
    let userId = req.cookies.userId;
    let sql = `select * from addresslist where userId=${userId}`;
    pool.query(sql, (err, result) => {
      if(err) {
        res.json({
          status:'-1',
          msg:err.message
        });
      } else {
        res.json({
          status:'1',
          msg:'',
          result:result
        });
      }
    });
  } else {
    res.json({
      status:'0',
      msg:'未登录'
    });
  }
})
module.exports = router;
