var express = require('express');
var router = express.Router();
var mysql = require('mysql');
var $conf = require('../conf/conf');
// 使用连接池
var pool = mysql.createPool($conf.mysql);
router.use(express.static('public'));
router.get('/', function(req, res, next) {
  if(pool) {
    var sql = 'select * from goods';
    pool.query(sql,(err, result) => {
      if (err) {
        res.send(err.message);
      }else {
        res.send( JSON.stringify(result));
      }
    });
    console.log('succee');
  }else{
    console.log('err');
  }

























  // var connection = mysql().conf;
  // connection.connect((err) => {
  //   if(err) {
  //     res.send(err);
  //   }else {
  //     res.send('success');
  //   }
  // });
//   res.send({
//   "status":"0",
//   "result":[
//     {
//         "productId":"10001",
//         "productName":"小米6",
//         "prodcutPrice":"2499",
//         "prodcutImg":"mi6.jpg"
//     },
//     {
//       "productId":"10002",
//       "productName":"小米笔记本",
//       "prodcutPrice":"3999",
//       "prodcutImg":"note.jpg"
//     },
//     {
//       "productId":"10003",
//       "productName":"小米6",
//       "prodcutPrice":"2499",
//       "prodcutImg":"mi6.jpg"
//     },
//     {
//       "productId":"10004",
//       "productName":"小米6",
//       "prodcutPrice":"2499",
//       "prodcutImg":"1.jpg"
//     },
//     {
//       "productId":"10005",
//       "productName":"小米6",
//       "prodcutPrice":"2499",
//       "prodcutImg":"2.jpg"
//     },
//     {
//       "productId":"10006",
//       "productName":"小米6",
//       "prodcutPrice":"2499",
//       "prodcutImg":"3.jpg"
//     },
//     {
//       "productId":"10007",
//       "productName":"小米6",
//       "prodcutPrice":"2499",
//       "prodcutImg":"4.jpg"
//     },
//     {
//       "productId":"10008",
//       "productName":"小米6",
//       "prodcutPrice":"2499",
//       "prodcutImg":"5.jpg"
//     },
//     {
//       "productId":"10007",
//       "productName":"小米6",
//       "prodcutPrice":"2499",
//       "prodcutImg":"4.jpg"
//     },
//     {
//       "productId":"10008",
//       "productName":"小米6",
//       "prodcutPrice":"2499",
//       "prodcutImg":"5.jpg"
//     }
//   ]
// });
});













// /* GET home page. */
// router.get('/', function (req, res) {
//    console.log("主页 GET 请求");
//    res.send('Hello GET');
// })
 
 
// //  POST 请求
// router.post('/', function (req, res) {
//    console.log("主页 POST 请求");
//    res.send({'id':'1','name':'wzz','age':'18'});
// })
 
// //  /del_user 页面响应
// router.get('/del_user', function (req, res) {
//    console.log("/del_user 响应 DELETE 请求");
//    res.send('删除页面');
// })
 
// //  /list_user 页面 GET 请求
// router.get('/list_user', function (req, res) {
//    console.log("/list_user GET 请求");
//    res.send('用户列表页面');
// })
 
// // 对页面 abcd, abxcd, ab123cd, 等响应 GET 请求
// router.get('/ab*cd', function(req, res) {   
//    console.log("/ab*cd GET 请求");
//    res.send('正则匹配');
// })


module.exports = router;
